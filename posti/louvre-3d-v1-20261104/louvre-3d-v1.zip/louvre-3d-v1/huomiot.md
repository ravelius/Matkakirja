# Louvre 21c — toimitushuomiot

Ensisijainen esine on `louvre.glb`. `vertailu/louvre-raaka.glb` on vain kevennysvertailu, ei toinen peliesine. Molemmissa sovelletaan samat pelimitat ja pyramidimuodon korjaus, jotta raaka/kevyt-esikatselut ovat vertailukelpoiset. Alkuperäiset koskemattomat Tripo-lataukset säilyvät T7:n `raw/`-kansiossa.

## Tekniset tulokset

| Ominaisuus | Tripo-raaka | Tripo-kevennys | Toimitettava kevyt |
|---|---:|---:|---:|
| Kolmiot | 47 499 | 28 010 | 28 014 |
| Tiedostokoko tavuina | 4 586 824 | 3 094 552 | 3430992 |
| Materiaalit / primitiivit | 1 / 1 | 1 / 1 | 1 / 1 |
| Tekstuurit | 2048 PBR | 2048 PBR | samat upotetut PBR-tekstuurit |
| Animaatiot / luurangot | 0 / 0 | 0 / 0 | 0 / 0 |

Kevennys vähensi kolmioita noin 41 %. Kaariarkadit, kuusi paviljonkia, sisäpiha ja kolme pyramidia säilyivät. Loppuviimeistelyn neljä lisäkolmiota sulkevat pienet lähde-kevennyksen pintareiät; niiden pisimmät reunat 2.56–5.01 pelimetriä. Lopullisen verkon hitsatun topologian aukko-/ei-manifold-/degeneraattitarkistus on `qa/geometry-check.json`:ssä. Tiedosto on upotettu GLB ilman Dracoa, opaque, ei solmuskaalaa. Alin Y = 0, pohjan keskipiste X/Z = 0; etelä +Z, itä +X, +Y ylös.

## Mitat ja muotokorjaus

- Ulkomitat 860 × 360 pelimetriä, kokonaiskorkeus 295.
- Kulmapaviljongit mitattu noin 294.3–295.0; keskipaviljongit noin 239.1 ja 240.0.
- Räystään ja siiven harjan viitebandit asetettu noin 120/160:een mitatun harmaan katon perusteella. Koristeet ja savupiiput saavat ylittää harjan. Lopullisen harmaan kattopinnan otoksessa alaraja on 119.98 ja 95. prosenttipiste 158.18 pelimetriä (179 pistettä). Tarkat kärkimittaukset ja käytetty valintarajaus QA:ssa.
- Iso pyramidi 145 × 145, korkeus 110 pihasta; pienet 48 × 48, korkeus 35. Pihan paikallinen Y noin 5.6, joten kärjet ovat 115.6 ja 40.6, eivät 110/35 maatasosta. Pyramidit on muotoiltu samasta verkosta, ja ne ovat topologisesti yhteydessä pihan pohjaan mutta selvästi erillään siivistä. Ne eivät ole erillisiä irrotettavia meshejä.
- Tripon matalan pyramidimuodon kärjet ja pinnat sovitettiin teräviksi olemassa olevaa UV-verkkoa ja tekstuuria säilyttäen, #2074-luvan mukaisesti. Tästä jää paikoin ruudukon venymää ja pihan tekstuurin suunnan muutosta pyramidien läheisyyteen. Läpinäkyvyyttä ei käytetä. Sininen tulee hyväksytystä vaimeasta 21d-kuvasta, ei 21b:n kylläisestä sinisestä.

## Sivukohtainen lähdevertailu

| Sivu | Havainto ja poikkeama lähteestä |
|---|---|
| Etelä +Z | Kolme paviljonkia ja pitkät siivet tunnistettavat, kaaret auki. Ikkunat, pilasterit, kerroslistat ja kattodormerit ovat lähdettä pelkistetympiä; koristeita on sulautunut tekstuuriin. Kevennys säilytti tämän yleisjaon. |
| Pohjoinen −Z | Kolme paviljonkia ja avoimet kaaret säilyivät. Pitkien siipien seinäpinnassa on etelää vähemmän ikkunadetaljeja ja dormereita; lähteen koristeellisuus ei toistu kokonaan. |
| Itä +X | Kaksi kulmapaviljonkia ja matala yhdysosa säilyivät. Yhdysosan ylemmät ikkunat ja dormerit ovat suurelta osin kadonneet; arcade on selvästi tunnistettava mutta pylväät ja kaariprofiilit karkeammat. |
| Länsi −X | Sama pääjako, mutta yhdysosa on lähdettä sileämpi, ikkunarivi ja dormerijako niukkoja. Kaaret säilyivät kevennyksessä. |

Nämä ovat alkuperäisen yhden viistokuvan Tripo-tulkinnan poikkeamia. Niitä ei peitetä kevennyksen onnistumisella. Lisäksi katon/pilasterien saumoissa näkyy paikoin tumma tekstuurijälki, eikä pieniä koristeita ole silotettu käsin. Karttaseppä arvioi lähdeuskollisuuden riittävyyden karttakäyttöön. Malli ei ole fotogrammetrisesti tarkka Louvre.

## Esikatselut ja kustannukset

11 pakollista 1024 × 1024 tarkistuskuvaa: raaka/kevyt neljältä sivulta, ylhäältä, lounas 60° ja koillinen 60°. Molemmat versiot samassa suunnassa ja samassa rajauksessa. Sama kevyt CPU-tarkistusvalo kuin NotreDame19b: laaja täyttö 0.80, päävalo 0.15 ja vastatäyttö 0.05; kuvat eivät ole pelikuvia. Tripon Remove Lighting oli päällä; tämän paikallisen työvaiheen yhteydessä ei leivottu varjoja tekstuureihin.

Yksi generointiyritys 45 krediittiä + yksi retopologia 5 krediittiä = 50. Saldo 16455 → 16405. Ensimmäinen valmistui noin 22.1x ja kevennys noin 22.13 Helsingin aikaa 4.11.2026. Tavoitearvio oli 45–90 min lähteen saapumisesta; toteutuneet ajat checkpointissa. Kahden epäonnistuneen oton raja ei ylittynyt.

Vastaanotto Karttaseppä→KK on vielä avoin. Peliä, git-työhaaraa, junaa tai julkaisua ei muutettu.
