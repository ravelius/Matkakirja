# Louvre 21c / lähteet ja tuotanto

Tilaus Karttaseppä #2070, täsmennys #2074; yksi liikkumaton karttamalli, ei junaan. Vastaanottaja Karttaseppä tarkistaa täysikokoisena ja vie KK:lle. Tämä paketti ei väitä vastaanottoa, omistajan hyväksyntää, peli-integraatiota tai julkaisua.

Ainoa generointisyöte: `lahteet/viisto-21d.png`, SHA256 `3347d55e006923d2e54485e87408bd8f0312ee8c9521f57fc28706828afa08da`. Toimittajan hyväksytty KUVAT-session lähde, luettu paikallisesta handoffista. Neljä `lahteet/julkisivut/`-kuvaa ovat sivukohtaisia QA-lähteitä. `sijoittelu-21b-ylhaalta.png` on vain sijoittelun tarkistus: sen voimakkaampi sininen ei ole nykyinen väriohje. Tarkennus 2074 korvaa tämän osan vanhasta 21c-tilauksesta.

Tripo Studio H3.1 Image, UltraMesh, 50k tavoite, 2K PBR, Remove Lighting päällä, AI Complete ja Generate in Parts pois. Yksi otto, job `c14990f2-2dd7-47ad-a753-527d47ed3a1f`, 45 krediittiä. Saman jobin Triangle Retopology, Smart Mesh pois, tavoite 28k, 5 krediittiä. Ei toista ottoa. Tripo Maxin olemassaoleva tilaus; ei uusia ostoja. Lähteiden käyttöketju on tilaajan hyväksytty tuotantoaineisto; tämän työn yhteydessä ei tehty uutta ulkopuolista lisenssiselvitystä eikä käytetty Googlen laattoja.

Alkuperäiset lähdetiedostot ja ladatut Tripo-GLB:t säilytetty muuttamatta T7:n työjuuressa. Raaka SHA256: `a86236b1b56cde174946f10b375d6e53749fa8920710a21ca32fdcb30d9396e7`; Tripo-kevennys SHA256: `5e0febb6f4db21d01929cc4e0cbd1ef711b0b40c19be27271be75244eb9783b3`.

Paikallinen viimeistely: mitoitus ja akselit sovellettu kärkiin; keskipaviljonkien korkeus sovitettu jatkuvasti. Pyramidien olemassa oleva verkko muotoiltu teräväkärkisille pinnoille #2074-luvalla; ei uutta malligenerointia. UV:t ja kaikki upotetut tekstuurit säilyivät tavuina samoina paikallisessa viimeistelyssä. Lopuksi neljä Tripo-kevennyksen pientä kolmionmuotoista pintareikää suljettu neljällä kolmiolla. Kaikki toimenpiteet ovat QA-raporteissa.

3D-sivulähteiden alkuperäinen posticommit: `a6d8ff12caee418a49a5340da4c580fea887ff01`; aloitustarkennus: `6f12565194862e6dcff16c9f4488b9bb7dc57d9d`. Tripo-työ: https://studio.tripo3d.ai/workspace/retopology/c14990f2-2dd7-47ad-a753-527d47ed3a1f
