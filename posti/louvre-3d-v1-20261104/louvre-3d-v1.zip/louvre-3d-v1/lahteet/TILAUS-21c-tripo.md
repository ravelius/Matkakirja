# Codex-tilaus 21c (Tripo 3D -sessio): Louvren malli kartalle (Karttaseppä 4.11.2026)

KK 4.11. 21.1x omistajan valtuutuksella: muoto ja mitat kelpaavat. Kuvat on tarkistettu (21a 627f58d04, 21b v2 04f853a91). Omistaja 18.27 (kortti): Louvre ja Sainte-Chapelle seuraavaksi; 19.03: mallin omat värit ja sama valo kuin Notre-Damella. Tripon pysyvä lupa (Raamattu 7.15, 11.6). Yksi malli. Ei junaan.

**Lähde vain:** `_review-pohjakuvat/`:n `etela.png`, `pohjoinen.png`, `ita.png`, `lansi.png` ja `_review-pyramidi-21b/ylhaalta.png`. Pyramidien väri ja koko `_review-pyramidi-21b/`:stä (`ylhaalta.png` lähteenä, `pelikulma.png` väri- ja koko-vertailuna: siinä etusivun keskipaviljonki on sivussa, joten rakennuksen lähde on julkisivut). Ei Googlen laattoja (2.91). Pohja `docs/moduulit/tuotantopohjat/codex-3d-toimitus.md`.

**Kaksi epäonnistunutta ottoa → viesti Karttasepälle ennen kolmatta.** Epäonnistunut tarkoittaa esimerkiksi umpeutunutta sisäpihaa, siipiin sulaneita pyramideja, möykkyisiä paviljonkeja tai kadonneita kaariarkadeja.

## Malli `louvre.glb`
- **Käyttö:** kartan esine, jota katsotaan ylhäältä ja viistosta kaikista suunnista. Näkyvät erityisesti katot, avoin sisäpiha ja pyramidit. **LIIKE:** ei liikettä, ei luurankoa.
- **Mitat pelikoossa (metriä, liioiteltu):** pituus 860, leveys 360, kulmapaviljonki noin 295, keskipaviljonki noin 240, siiven harja noin 160, räystäs noin 120, iso pyramidi kuten yläkuvassa (ei pienennetä).
- **Sisäpiha on avoin ja tasainen:** pyramidit ovat erillisiä umpinaisia kappaleita pihan päällä, ja piha näkyy niiden ympärillä. Lasi on läpinäkymätöntä tekstuuria. **Omistaja 21.24: pyramidi suurena ja sinisenä, koska se on kaikkein tunnistettavin asia; sinisen on näyttävä kaukaa. Jos pyramidi sulaa keskipaviljonkiin, ilmoita Karttasepälle ennen toimitusta.**
- **Akselit ja pivot:** +Y ylös, eteläsivu kohti +Z, origo pohjan keskellä, alin piste y = 0, skaala sovellettuna. Kytkijä kääntää mallin kartalle.
- **Pelkkä rakennus:** ei maata pihan ulkopuolella, ei puita eikä ihmisiä. Tasainen pohja, ei rakoa eikä kelluvia osia.
- **Tiedosto:** GLB, kaikki upotettuna, ei Dracoa, enintään 15 Mt, enintään 300 primitiiviä, tavoite yksi materiaali, tekstuuri enintään 2048, ei läpinäkyvyyttä. Portin raja on 100 000 kolmiota. Ei varjoja tekstuuriin.

## Kevennys
**Yli 30 000 kolmiota tai yli 2048 tekstuuria: kevennä Tripon omilla työkaluilla** ja toimita kevyt versio. Jos kevennys vie arkadit tai pyramidit, kerro se ja toimita molemmat.

## Toimitus `louvre-3d-v1/` (aja ensin `node tools/codex-3d-tarkistus.mjs`)
`louvre.glb`, `SHA256SUMS`, `LAHTEET.md`; `esikatselu/{raaka,kevyt}-{etela,pohjoinen,ita,lansi}.png`, `esikatselu/ylhaalta.png`, pakolliset `esikatselu/pelikulma-{lounas,koillinen}.png` noin 60°:n kulmasta; `huomiot.md`: kolmiot, tekstuuri, koko ennen kevennystä ja sen jälkeen, otot, poikkeamat, mitatut korkeudet, krediittitilanne.

Viesti vain claude/postilaatikko-haaraan. Karttaseppä tarkistaa toimituksen täysikokoisena ja vie sen KK:lle ennen omistajaa. Peliin kytkijän jakaa PT toimituksen jälkeen.
