# Notre-Dame 3D — lähteet ja työkalut

Tekijä: Codex / omistajan Matkakirja-projekti. Malli tuotettiin omistajan Tripo Max -tilillä Chrome-käyttöliittymässä, H3.1:n kolmannesta hyväksytystä kokeesta. Käyttöoikeuden peruste on omistajan palvelutilaus; aineistolle ei tässä aseteta uutta CC-lisenssiä. Ei ostettua ulkopuolista mallia.

Ainoat Tripo-syötteet: neljä hyväksyttyä ImageGen-K2-kuvaa `lahteet/{lansi,etela,pohjoinen,ita}.png`. Tarkisteet SHA256SUMS-tiedostossa. Alkuperäinen lähdehistoria ja oikeustiedot ovat `lahteet/kuvapohjien-lahteet.md`:ssä. Kuvat eivät muuttuneet latauksessa. Ei K2/K3-pelikulmaa, Googlen laattoja tai uusia ulkopuolisia kuvia.

Tuotantolupa: Karttasepän 19b K2 -avaus383e83d6514fabdcaffd90cd5985d1351301b9ce ja kolmannen oton ohjeblob daf99ed5439d48148389df7a1db9756e2f1b6148. Kuittaus838350014f1bfff27a801fc21957aa913791c4f0. Kokeiden ID:t ja kustannukset huomiot.md:ssä ja qa/-lokeissa.

Paikallinen jälkityö: Python/NumPy-mitoitus ja tornikorkeuden tasaus, normaaleihin vastaava muunnos, GLB-pakkaus; UV, topologia ja tekstuurit säilyvät. Esikatselut rasteroidaan toimituksen GLB-geometriasta. Uutta rakennusta ei rakennettu koodilla. Työkalut, natiivit lähteet ja täydellinen QA-työhistoria säilyvät työjuuressa:
`/Volumes/T7 4TB/ChatGPT-Codex-active/ChatGPT/Matkakirja 2/output/notre-dame-3d-19b-20261104/`.
