# Notre-Dame 19b K2 — v1, toimitus tarkistettavaksi

Tyyppi: rakennus/esine. Kummassakaan GLB:ssä ei ole liikettä.

Käyttö: liioiteltu staattinen kartan maamerkki. Ei peliin kytketty eikä junaan julkaistu. Karttasepän täysikokoinen tarkistus ja KK/omistajan hyväksyntä ovat seuraavat vaiheet.

## Mitat ja tornit

- Lopullinen `notre-dame.glb`: leveys **240**, huipun korkeus **620**, alin Y **0**. +Y ylös, länsijulkisivu +Z. Skaala sovellettu geometriaan, pohjan koko ulkovaipan keskikohta X/Z = 0.
- Runko **250** länsijulkisivun etutason ja kuorin takaseinän mittatason välillä. Kokonaispituus tukikaarineen **280,133**, tilauksen 277–286 viitevälin sisällä. Takaseinän mittataso on tarkastetun seinäpinnan 55 kärjen mediaani: menetelmä ja alkuperäiset rajat `qa/normalization.json`. Se ei ole koko ulkovaipan pituus.
- Molempien tornien korkein yläreunan koristepiste **540,000 / 540,000**, ero **0,000** tallennetun float32-geometrian tasolla. Tämä on tornin ylin piste koristeineen, ei kattotasanteen lattia. Tripon pieni korkeusero tasattiin paikallisesti jatkuvalla pystysovituksella yläosan alueella.
- **Poikkeama tavoitekuvaan:** tornien mitattu ylä/ala-leveneminen on pohjoisessa **1,069 ×**, etelässä **1,101 ×**, joten ne ovat tilattua noin **1,25 ×** suoremmat. Leveys mitataan varsinaisen tornirungon X-suuntaisista vyöhykkeistä, alkuperäiset Y-välit 0,48–0,52 ja 0,76–0,80; keskijulkisivun koristeet rajattu ulos. Mittaus näkyy JSONissa. Levenemistä ei esitetä hyväksytyksi 1,25-suhteeksi.

## Kevennys ja pinnat

| | Raaka | Tripo-kevennetty |
|---|---:|---:|
| Kolmiot | 46 153 | 20 003 |
| Natiivi tiedostokoko | 5 238 728 tavua | 2 920 912 tavua |
| Toimitetun mitoitetun tiedoston koko | 5 238 860 tavua | 2 921 020 tavua |
| Materiaalit / primitiivit | 1 / 1 | 1 / 1 |
| Tekstuurit | 3 × 2048² | 3 × 2048² |

Tripon oma Retopology, Triangle, Smart Mesh pois, tavoite20 000, 5 krediittiä. Kolmiomäärä väheni 56,7 %. Raaka säilyy vertailussa ja muuttumaton natiivilähde työjuuren `raw/`-kansiossa. Kevennys säilytti kahden tornin aukot, ruusuikkunat, portaalit, kuorin ja tukikaaret. Ohut huippu säilyi; aivan ylimmästä pienestä kärjestä katosi yksityiskohtaa. Lopullinen korkeus sovitettiin620:een. Ei uutta tekstuurigenerointia; paikallinen mitoitus säilyttää kevennetyn mallin UV:t, indeksit ja upotettujen tekstuurien tavut muuttumattomina. Normaaleihin sovellettiin vastaava muunnos. Ei Dracoa, meshoptia, läpinäkyvyyttä, luurankoa tai animaatioita.

## Otokset ja kustannukset

1. Smart Mesh P2.0 `18789423-46e3-4b85-ab83-56864de7c918`: 100 krediittiä. Hylätty: kaksi huippua ja puuttuvaa julkisivua. Ei teksturoitu jatkona.
2. H3.1 `73ba3ee1-0f0c-4811-abcd-6690c5b426df`: 45 krediittiä. Hylätty: tornipää ja kuoripää sekoittuivat kuvasuuntien vuoksi.
3. Karttasepän erikseen hyväksymä H3.1 `cb47518e-f93c-4d81-85ce-9a91014e6978`: 45 krediittiä. Front=lansi, Left=etela, Right=pohjoinen, Back=ita. Rakenne tarkistettu todellisesta GLB:stä kuudelta suunnalta ennen kevennystä. Ei neljättä ottoa.
4. Saman kolmannen mallin Tripo-kevennys: 5 krediittiä. UI säilytti saman asset-URL:n, erillistä job-ID:tä ei näytetty.

Yhteensä **195 krediittiä**, saldo **16 950**. Ei ostoja. Kaikki lähde-PNG:t muuttumattomia; pelikulma ei ollut generointisyöte.

## Esikatselut ja tarkistus

`esikatselu/raaka-*.png` ja `kevyt-*.png`: mitoitetut GLB:t samoilla ortografisilla kameroilla ja tasaisella täytevalolla. Länsi+Z, pohjoinen−X, itä−Z, etelä+X. `pelikulma-lounas.png` ja `pelikulma-koillinen.png`: 60° yläviisto. Nämä ovat todellisen toimitettavan mallin esikatseluja, eivät pelistä otettuja kuvia. Kevyt CPU-tarkistus, ei Blender-videota. Värikartta ja pinnan normaalit mukana esikatselussa; normaalitekstuurin mikroyksityiskohdat eivät sisälly tähän CPU-esikatseluun.

Tekninen vientiportti ajetaan ennen postitusta. Vastaanottaja tarkistaa varsinaisen pelivalon, mittasuhteet tavoitekuvaan ja mobiilipainon iPadilla. V1:n vastaanotto, omistajan hyväksyntä, peli-integraatio ja julkaisu eivät ole vielä vahvistettuja.
