# Codex-tilaus 19b k2 (Tripo 3D -sessio): Notre-Damen malli kartalle, AVATTU (Karttaseppä 4.11.2026)

Omistaja 4.11. klo 09.13 (kortti): 3D-koe kyllä. Omistaja 10.22: "Lisää liioittelua". **Omistaja 11.26 (kortti "Kelpaako tämä kirkko Tripon malliksi?"): "oikein hyvä, ainoastaan lähempänä kameraa oleva torni on jostain syystä matalampi kuin toinen torni. korjaa ne vielä yhtä korkeiksi, niin sitten voi heti aloittaa".** Tripon pysyvä lupa (Raamattu 7.15, 11.6). Yksi malli. Ei junaan. **Tämä avaa 19b:n ja korvaa `TILAUS-19b-tripo.md`:n** paitsi siltä osin kuin alla viitataan siihen.

**Lähde vain neljä sivukuvaa `_review-pohjakuvat-k2/`:ssa: `lansi.png`, `pohjoinen.png`, `ita.png`, `etela.png`.** **`pelikulma.png` EI ole lähde:** siinä etumainen torni näyttää matalammalta, ja se on juuri omistajan huomauttama vika. Sivukuvissa tornit ovat yhtä korkeat (KK mittasi lansi.png:stä ja ita.png:stä yläreunan y 394). Ei vanhoja 19a-kuvia eikä Googlen laattoja (2.91). Pohja `docs/moduulit/tuotantopohjat/codex-3d-toimitus.md`.

**Kaksi epäonnistunutta ottoa → viesti Karttasepälle ennen kolmatta.** Epäonnistunut tarkoittaa esimerkiksi möykkyisiä torneja, kadonneita tukikaaria, väärää tornin muotoa tai eri korkuisia torneja.

## Muuttunut `TILAUS-19b-tripo.md`:stä
- **Tornit täsmälleen yhtä korkeat (omistajan ehto).** Mittaa valmiista mallista kummankin tornin yläreuna ja kerro luvut `huomiot.md`:ssä. Jos Tripon tulos eroaa, korjaa se ennen toimitusta tai käytä uutta ottoa.
- **Mitat pelikoossa (metriä, liioiteltu):** leveys 240, pituus 250, tornit 540, huippu 620. Sivukuvien pituus on tukikaarineen 277–286: tee **runko 250:een**, anna tukikaarten ulottua sen yli enintään kuvien verran, ja kerro toteutunut pituus huomioissa.
- **Tornit levenevät ylöspäin noin 1,25 ×.** Tornit hallitsevat, katot selvästi niiden alapuolella. Suhdetta ei ole kalibroitu kaikista suunnista; jos malli jää suoremmaksi, kerro se.
- **Esikatselut:** `esikatselu/pelikulma-{lounas,koillinen}.png` noin 60°:n kulmasta ylhäältä ovat pakolliset, koska KK vie ne omistajalle. Kuvat-sessio tekee erillisen pelikulman vertailukuvaksi; **älä odota sitä,** se ei pidättele tätä työtä.

## Ennallaan `TILAUS-19b-tripo.md`:stä
Käyttö ja LIIKE, akselit ja pivot, pelkkä rakennus, tiedoston rajat, kevennys (yli 30 000 kolmiota tai yli 2048 tekstuuria) ja toimituksen sisältö `notre-dame-3d-v1/`-kansioon (aja ensin `node tools/codex-3d-tarkistus.mjs`).

Viesti vain claude/postilaatikko-haaraan. Karttaseppä tarkistaa toimituksen täysikokoisena ja vie sen KK:lle. Peliin kytkijän jakaa PT toimituksen jälkeen.
