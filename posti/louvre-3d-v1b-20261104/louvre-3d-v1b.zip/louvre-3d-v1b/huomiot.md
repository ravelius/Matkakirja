# Louvre21c v1b — UV-korjauksen toimitushuomiot

Ensisijainen malli on `louvre.glb`. Tämä korvaa v1:n teknisessä karttakokeessa, mutta ei väitä KK:n/omistajan hyväksyntää, peli-integraatiota tai julkaisua. Vastaanottaja tarkistaa mustan laikan ensin.

## Korjattu

Musta kattolaikka ja keskipaviljonkien mustat pinnat johtuivat Tripon kevennyksen puuttuvista UV-kartoista. V1:n huomio “lähdetekstuurin poikkeama” oli puutteellinen: kyseessä oli korjattava tekninen UV-virhe, jonka tavallinen geometriaportti jätti havaitsematta.

- Sama28014 kolmion ja22765 kärjen malli;3 430 992 tavua, yksi materiaali/primitiivi ja upotetut2K-PBR-kuvat. Ei luurankoa, animaatiota, läpinäkyvyyttä taiDracoa.
- Mitat860×360, korkeus295; +Yylös, etelä+Z, itä+X, pohja keskellä ja minY0. Pyramidit145×145×110 ja2×48×48×35 pihatasosta säilyvät.
- Täsmälleen nollan UV-alan kolmiot58→0, 3D-ala2180.2334→0 m².
- Näistä kaikki kolmeUV:tä pisteessä(0,1):48→0, 3D-ala2093.4387→0 m².
- Tilaajan81-tulos toistuu kynnyksellä UV-ala≤1e-7; ennen81/2288.7350 m², jälkeen68/448.8537 m². Nämä68 ovat aidosti positiivisen mutta pienen UV-alan pintoja, eivät romahtaneita. Naapurialueen sisään rajattu UV-projektio voi tehdä UV-alasta pienen; lukuja ei ole piilotettu. Raakavertailussakin on tällä kynnyksellä100 pientä aluetta.
- Vain72 UV-kärkeä/482 tavua muutettu. Kaikki geometria-, indeksi-, normaali-, kuva-, materiaali- ja JSON-tavut säilyvät identtisinä. Vanhat lähteet ja v1 säilyvät.

Kaikki11 pyydettyä1024×1024 esikatselua renderöity uudelleen samoin kameroin ja valoin. Mustaksi määritelty koko kuvan pikseli, jonka max(R,G,B)≤8; myös täysi0 ja varovaisempi≤16 lasketaan erikseen. Kuvia ei rajattu mittauksesta eikä jälkikäsitelty mustien poistamiseksi. Tarkat kuvakohtaiset määrät `qa/v1b-black-pixels.json`:ssä. Esikatselut ovat mallikuvia, eivät pelikuvia.

## Katon sahalaita, lisäys2079

Sahalaitaa ei madallettu tässä v1b:ssä. Piikit ovat kattoikkunoiden taustojen ja lappeen yhteistä pintaverkkoa; niiden turvallista erottamista ja madallusta ilman ikkunaprofiilin, lappeen tai UV-liitoksen sivuvaikutusta ei vahvistettu tämän rajatun korjauksen yhteydessä. Lisäys2079 käski olla viivyttämättä mustan laikan korjausta, joten toimitus säilyttää geometrian kokonaan. Koilliskuvassa näkyvä piikkirivi on edelleen avoin visuaalinen havainto, ei korjatuksi väitetty ominaisuus.

## Muut säilyvät lähdepoikkeamat

Etelän julkisivu on lähdettä pelkistetympi, pohjoisessa sekä erityisesti itä/länsi-yhdysosissa on vähemmän ikkunoita ja dormereita. Kaariarkadit ja kuusi paviljonkia säilyvät. Pyramidin ruudukossa ja lähipihassa on alkuperäisen muotosovituksen UV-venymää. Näitä ei muutettu2078-rajauksen mukaisesti. V1:n täydellinen neljän sivun vertailu on `qa/history-v1/huomiot-v1.md`:ssä; sen vanha mustalaikkahuomio korvautuu tämän version korjauksella.

## Työ ja vastaanotto

Korjaus0 krediittiä; koko Louvre-tuotanto edelleen50 krediittiä, kirjattu Tripo-saldo16405. Alkuperäinen yksi generointi ja yksi kevennys säilyvät; uusia ottoja ei tehty. Kevyt yhden säikeen esikatselu, ei raskasta Blender-renderöintiä. Riippumaton kevyt apuagentti tarkistaa tavut, UV-luvut ja kuvat. Karttasepän/KK:n v1b-vastaanotto ja hyväksyntä ovat erillisiä. Ei junaa, peliä tai julkaisua.
