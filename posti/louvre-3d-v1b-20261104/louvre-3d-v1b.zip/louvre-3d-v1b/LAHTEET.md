# Louvre 21c v1b / lähteet ja tuotanto

Tilaus Karttaseppä #2070, täsmennys #2074; yksi liikkumaton karttamalli, ei junaan. Vastaanottaja Karttaseppä tarkistaa täysikokoisena ja vie KK:lle. Tämä paketti ei väitä vastaanottoa, omistajan hyväksyntää, peli-integraatiota tai julkaisua.

Ainoa generointisyöte: `lahteet/viisto-21d.png`, SHA256 `3347d55e006923d2e54485e87408bd8f0312ee8c9521f57fc28706828afa08da`. Toimittajan hyväksytty KUVAT-session lähde, luettu paikallisesta handoffista. Neljä `lahteet/julkisivut/`-kuvaa ovat sivukohtaisia QA-lähteitä. `sijoittelu-21b-ylhaalta.png` on vain sijoittelun tarkistus: sen voimakkaampi sininen ei ole nykyinen väriohje. Tarkennus 2074 korvaa tämän osan vanhasta 21c-tilauksesta.

Tripo Studio H3.1 Image, UltraMesh, 50k tavoite, 2K PBR, Remove Lighting päällä, AI Complete ja Generate in Parts pois. Yksi otto, job `c14990f2-2dd7-47ad-a753-527d47ed3a1f`, 45 krediittiä. Saman jobin Triangle Retopology, Smart Mesh pois, tavoite 28k, 5 krediittiä. Ei toista ottoa. Tripo Maxin olemassaoleva tilaus; ei uusia ostoja. Lähteiden käyttöketju on tilaajan hyväksytty tuotantoaineisto; tämän työn yhteydessä ei tehty uutta ulkopuolista lisenssiselvitystä eikä käytetty Googlen laattoja.

Alkuperäiset lähdetiedostot ja ladatut Tripo-GLB:t säilytetty muuttamatta T7:n työjuuressa. Raaka SHA256: `a86236b1b56cde174946f10b375d6e53749fa8920710a21ca32fdcb30d9396e7`; Tripo-kevennys SHA256: `5e0febb6f4db21d01929cc4e0cbd1ef711b0b40c19be27271be75244eb9783b3`.

Paikallinen viimeistely: mitoitus ja akselit sovellettu kärkiin; keskipaviljonkien korkeus sovitettu jatkuvasti. Pyramidien olemassa oleva verkko muotoiltu teräväkärkisille pinnoille #2074-luvalla; ei uutta malligenerointia. V1:n paikallisessa viimeistelyssä UV:t ja upotetut tekstuurit säilyivät. V1b korjaa UV-virheen jäljempänä kuvatulla tavalla. Lopuksi neljä Tripo-kevennyksen pientä kolmionmuotoista pintareikää suljettu neljällä kolmiolla. Kaikki toimenpiteet ovat QA-raporteissa.

3D-sivulähteiden alkuperäinen posticommit: `a6d8ff12caee418a49a5340da4c580fea887ff01`; aloitustarkennus: `6f12565194862e6dcff16c9f4488b9bb7dc57d9d`. Tripo-työ: https://studio.tripo3d.ai/workspace/retopology/c14990f2-2dd7-47ad-a753-527d47ed3a1f

## V1b UV-korjaus #2078, lisäys #2079

Tilaus2078: commit `4f53610fc497e2f680f23f41332c1766fa0c55d4`, blob `78dafd719a7f0a0318c6e5537c01233db62eef49`. Lisäys2079: commit `8a6b149ed8ccd4e3ea92ea3f3016a9fc34dee77b`, blob `8e740f53ac414bc03531863d87160f910cd8b65f`. Ei uutta Tripo-kutsua, 0 lisäkrediittiä.

48 mustaan atlasnurkkapisteeseen romahtanutta UV-kolmiota oli jo Tripon kevennyslatauksessa. Raaka- ja retopomallin tekstuuriatlaksilla on eri sisältö; raakakoordinaattien suora kopiointi olisi väärin. Puuttuville alueille käytettiin saman kevennetyn mallin lähimmän sopivansuuntaisen naapurin UV-pintaa, yhtenäinen projektio naapurin atlasalueen sisälle. Pienet täsmälleen romahtaneet reunat avattiin 0.2 tekstuuripikselin UV-liikkeellä nykyisellä atlasalueella. Lisäksi mustapikselitarkistuksen löytämä atlasreunavirhe korjattiin kolmion18662 UV-siirrolla (+2,-2 tekstuuripikseliä).

72 kärjen UV:t eli482 tiedostotavua muuttui. Kaikki muut GLB-tavut ovat identtiset v1:een: geometria, indeksit, normaalit, tekstuurit, materiaalit, JSON ja mitat. Lähdemallit, v1 ja alkuperäiset kuvat säilyvät. Raportin donorFace-kentät kertovat lähinaapurit; mitään tekstuurikuvaa ei maalattu eikä generoitu.
