# Lähteet ja tuotannon rajat

Omistajan #791 päätös: posti/paatoimittaja-codex-omistaja-0740-osamallit-esineet-20261021.md, commit 29b57268befcce7a8da4b187c9221f5fd4098933. Vanha KK-kortti määrittää neljä osaa ja liikkeen; kortin suunnitelmavaiheen lupatila on historiaa, omistajan erillinen #791 rajasi tuotannon tasan neljään ottoon.

Tripo Studio selaimella, omistajan olemassa oleva Max-tilaus; Smart Mesh P2.0, Triangle, tavoite 5000, yksi malli per painallus. Neljä mallia ×100 =400 kredittiä, havaittu saldo 22450 →22050 ennen erillisen #794:n aloitusta. Ei API:a eikä krediittiostoa. Ei Texture/Retopo/Segmentation/Free Retry -kutsuja. Tekstuureja ei syntynyt tähän geometria-ajoon.

Ovet tuotettiin tekstistä; portaan ja tasanteen syötteenä olivat omat kokonaan uudet sisäisellä imagegen-työkalulla luodut kuvareferenssit. Ei Googlen laattoja, muiden tekijöiden kuvia, logoja tai suojattujen teosten referenssejä. AI-kuvat ovat tuotantoreferenssejä, eivät todellisten rakennusten mittadokumentteja. Omien kuvien käyttöoikeus ei ole erillinen lainopillinen lausunto Tripo-tilin sopimusehdoista.

Kaikki GLB-geometria on alkuperäistä Tripo-tulosta, ei käsin rakennettua korvaavaa geometriaa. Natiivin noin yhden yksikön normalisointi ei todista todellista metrimittaa tai reittiin sovitusta. Niitä ei ole tehty tässä paketissa. Muotoportti erotetaan visuaalisesta ja toiminnallisesta hyväksynnästä; ovien liike ja kaikkien materiaalit/sovitus jäävät QA.jsonin osoittamiin tiloihin.
