# #791: neljän oton alkuperäiset tulokset vastaanottotarkistukseen

Kaikki neljä sallittua ottoa tehtiin kerran ja alkuperäiset GLB:t on varmennettu. **Tämä ei ole ilmoitus neljästä toimintavalmiista peliosasta.** Portaan ja tasanteen staattinen muoto on tarkistettu Tripon esikatselusta; sovitus kuuluu Lavastajalle. Kaikki neljä ovat teksturoimattomia geometrioita.

Palatsioven itsenäisten ovilehtien liike-ehto ei täyty tässä natiivissa: yksi mesh/solmu, yhdistävä alareuna, ei erillisiä saranoita eikä animaatiota. Ristikko-oven sarana, liike ja vapaa kulkuaukko ovat toteuttamatta. Näitä ei saa merkitä pelihyväksytyiksi eikä lisäottoja tehdä vanhalla luvalla. Jos vastaanottaja ei voi viimeistellä nykyistä geometriaa, uusi otto vaatii uuden KK-kortin.

QA.json kertoo per-osan todellisen tilanteen. GLB:t, natiivien tarkisteet, käytetyt kuvareferenssit, saatavilla olevat UI-kuvat ja neljän kutsun loki ovat paketissa. Unity/R2/main/julkaisuun ei ole tehty muutoksia.
