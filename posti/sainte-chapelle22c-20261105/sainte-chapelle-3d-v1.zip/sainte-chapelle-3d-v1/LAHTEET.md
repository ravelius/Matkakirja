# Lähteet ja tuotantotapa

Sainte-Chapelle22c, tilaus #2082 / Karttaseppä 5.11.2026. Tämä on pelin karttaesine, ei mittatarkka dokumentointi historiallisesta rakennuksesta.

Tekijä/työkalut: Codex, Tripo Studio H3.1 Multi-view + Tripon Retopology; paikallinen mitoitus ja rajatut pinta-/geometriakorjaukset. Ei animaatiota eikä luurankoa.

Lähteinä vain projektin hyväksymät neljä kuvakulmaa. Hyväksyntä ja käyttövaltuutus: tilaus22c, postilaatikon avauscommit `7555488f5cfeafc24763993001c051ef0626b5ed`. Itäkuva on hyväksytty22b, vanhaa hylättyä itäkuvaa ei käytetty. Ei Googlen 3D-laattoja eikä uusia kolmannen osapuolen kuvia. Tripon käyttö tapahtui omistajan olemassa olevalla tilillä ja valtuutuksella; uusia lisenssejä tai palveluita ei hankittu.

| Lähde | Käyttö | SHA256 |
|---|---|---|
| _review-ita-22b/ita.png | Tripo-monikuvasyöttö | `3afd06b801090cc2d6b3c6e2273eaf945874d1bf6e64c33829dd7e1e31320854` |
| _review-pohjakuvat/lansi.png | Tripo-monikuvasyöttö | `ae450facef5e69edf720240109f30cb10c2deadf0127bf0997e865e9af5b6606` |
| _review-pohjakuvat/etela.png | Tripo-monikuvasyöttö | `b8edb4bc171ad54d679ffd28ca4f3e18aaa93307449d9c7d4b5d826b59281c3c` |
| _review-pohjakuvat/pohjoinen.png | Tripo-monikuvasyöttö | `ac063d9a2e19a603a7bfadcbd728ab50fb1eec6bcc36cb6453182c8ee3445090` |
| _review-pohjakuvat/pelikulma.png | vain QA, ei syöte | `6fc3acb802a80393c5d0be6ad086b83e805c609b876c0831786823145fb437f5` |

Hyväksytyt lähdetiedostot ja muuttumattomat Tripo-viennit säilyvät T7-työpaketissa: `/Volumes/T7 4TB/ChatGPT-Codex-active/ChatGPT/Matkakirja 2/output/sainte-chapelle-22c-2082-20261105`. Alkuperäiset toimituslähteet: `/Users/Shared/Claude/proto-3d/_tyo/codex/pariisi-sainte-chapelle-20261104/`.

Tripo-otot ja alkuperäisten GLB-tiedostojen tiivisteet on kirjattu `qa/provenance-costs.json`-tiedostoon. Toimitusmalli on otosta02 johdettu, ja sen kaikki tekstuurikuvien tavut ovat samat kuin otoksen02 Retopology-viennissä.
