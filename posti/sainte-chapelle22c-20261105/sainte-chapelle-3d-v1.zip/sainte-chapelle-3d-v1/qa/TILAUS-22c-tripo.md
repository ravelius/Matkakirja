# Codex-tilaus 22c (Tripo 3D -sessio): Sainte-Chapellen malli kartalle (Karttaseppä 5.11.2026)

KK 5.11. omistajan valtuutuksella: 22b hyväksytty, sivukuvan ja itäpäädyn ristin 10–20 px:n ero kelpaa. KK 4.11.: suhteet 106 × 182, räystäs 130, harja 188, huippu 320. Omistaja 18.27 (kortti, Raamattu 2.206): Sainte-Chapelle seuraavaksi, oma malli; 19.03: mallin omat värit ja sama valo kuin Notre-Damella. Tripon pysyvä lupa (Raamattu 7.15, 11.6). Yksi malli. Ei junaan.

**Lähde vain nämä neljä sivua monikuvasyöttöön:**
- itä `_review-ita-22b/ita.png` (SHA256 `3afd06b8…`), EI `_review-pohjakuvat/ita.png`: se on hylätty.
- länsi `_review-pohjakuvat/lansi.png` (`ae450fac…`)
- etelä `_review-pohjakuvat/etela.png` (`b8edb4bc…`)
- pohjoinen `_review-pohjakuvat/pohjoinen.png` (`ac063d9a…`)

**Tarkistuslähde, ei syöte:** `_review-pohjakuvat/pelikulma.png` (`6fc3acb8…`). Valmista mallia verrataan siihen samasta kulmasta. Ei Googlen laattoja (2.91). Pohja `docs/moduulit/tuotantopohjat/codex-3d-toimitus.md`.

**Kaksi epäonnistunutta ottoa → viesti Karttasepälle ennen kolmatta.** Epäonnistunut tarkoittaa esimerkiksi katkennutta tai sulanutta huippua, kadonneita korkeita ikkunoita, möykkyisiä tukipilareita tai itäpäätyä, jossa on liuskekatto kivisen kolmiopäädyn tilalla.

## Malli `sainte-chapelle.glb`
- **Käyttö:** kartan esine, jota katsotaan ylhäältä ja viistosta kaikista suunnista. Näkyvät erityisesti katto, huippu ja pitkien sivujen ikkunat. **LIIKE:** ei liikettä, ei luurankoa.
- **Mitat pelikoossa (metriä):** leveys 106 (pohjoinen–etelä), pituus 182 (länsi–itä), räystäs 130, harja 188, huippu ristin kanssa 320. Karttasepän kytkentä sovittaa lopullisen koon kartalla; suhteet pidetään.
- **Huippu:** ohut mutta ehjä ja umpinainen ristiin asti, ei irtonaisia paloja. Jos huippu ei kestä kevennystä, kerro se ja toimita molemmat versiot.
- **Harjan koristeet:** matalat ristit eivät saa muuttua sahalaidaksi (Louvren v1:n vika). Mieluummin yksinkertainen ehjä harja kuin piikkirivi. Kerro `huomiot.md`:ssä, jos jouduit tekemään näin.
- **Itäpääty:** kivinen kolmiopääty, risti sen kärjessä ja huippu takana, kuten `ita.png`:ssä. Länsipäädyn ruusuikkuna ja kulmatornit kuten `lansi.png`:ssä.
- **Akselit ja pivot:** +Y ylös, eteläsivu kohti +Z, itä kohti +X, origo pohjan keskellä, alin piste y = 0, skaala sovellettuna. Kytkijä kääntää mallin kartalle.
- **Pelkkä rakennus:** ei maata, ei puita eikä ihmisiä. Tasainen pohja, ei rakoa eikä kelluvia osia.
- **Tiedosto:** GLB, kaikki upotettuna, ei Dracoa, enintään 15 Mt, enintään 300 primitiiviä, tavoite yksi materiaali, tekstuuri enintään 2048, ei läpinäkyvyyttä. Portin raja on 100 000 kolmiota. Ei varjoja tekstuuriin.

## Kevennys
**Yli 30 000 kolmiota tai yli 2048 tekstuuria: kevennä Tripon omilla työkaluilla** ja toimita kevyt versio. Jos kevennys vie ikkunat, pinnakkeet tai huipun, kerro se ja toimita molemmat.

**Louvren oppi, tarkista ennen toimitusta:** kevennys voi romahduttaa UV:t ehjään verkkoon, eikä `codex-3d-tarkistus.mjs` huomaa sitä. Laske nollan UV-alan kolmiot ja niiden 3D-ala sekä mustat pikselit jokaisesta esikatselusta ja kirjaa luvut `huomiot.md`:hen. Katso kaikki kuvat täysikoossa.

## Toimitus `sainte-chapelle-3d-v1/` (aja ensin `node tools/codex-3d-tarkistus.mjs`)
`sainte-chapelle.glb`, `SHA256SUMS`, `LAHTEET.md`; `esikatselu/{raaka,kevyt}-{etela,pohjoinen,ita,lansi}.png`, `esikatselu/ylhaalta.png`, pakolliset `esikatselu/pelikulma-{lounas,koillinen}.png` noin 60°:n kulmasta; `huomiot.md`: kolmiot, tekstuuri, koko ennen kevennystä ja sen jälkeen, otot, poikkeamat, mitatut korkeudet, UV-luvut, krediittitilanne.

Viesti vain claude/postilaatikko-haaraan. Karttaseppä tarkistaa toimituksen täysikokoisena ja vie sen KK:lle ennen omistajaa. Peliin kytkijä on Karttaseppä.
